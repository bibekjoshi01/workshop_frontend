// import { TabsContent } from "@/components/ui/tabs";
// import WorkAndEducationCard from "./workAndEducationCard";

// export default function WorkAndEducation() {
//   return (
//     <TabsContent className="pt-0 mt-0" value="work-and-education">
//       <WorkAndEducationCard />
//     </TabsContent>
//   );
// }


// FIXME  -  I DONT THINK THIS IS REQUIRED ?? 
// WE ARE ALREADY SHOWING WORK AND EDUCATION IN THE OVERVIEW TABS