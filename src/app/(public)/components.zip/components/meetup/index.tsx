import PastMeetUps from "./pastMeetups";
import WhyMeetUp from "./whyMeetup";

export default function MeetUps() {
  return (
    <>
      <WhyMeetUp />
      <PastMeetUps />
    </>
  );
}
