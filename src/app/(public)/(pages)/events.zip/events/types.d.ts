interface eventDataTypes {
    uuid: string;
    slug: string;
    thumbnail: string;
    organizerFullName: string;
    title: string;
    categoryName: string;
    eventType: string;
    eventDatetime: string;
    location: string;
    duration: string;
    noOfAttendees: string;
  }
  