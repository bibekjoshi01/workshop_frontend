import AllEventsSkeleton from "../../components/skeleton/all-events-skeleton";

export default function Loading() {
  return <AllEventsSkeleton />;
}
