import EventsSkeleton from "@/app/(public)/components/skeleton/event-skeleton";

export default function Loading() {
  return <EventsSkeleton />;
}
